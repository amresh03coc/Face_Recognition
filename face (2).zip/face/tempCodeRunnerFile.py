elon_image= face_recognition.load_image_file("image/elon.jpg")
# elon_encoding = face_recognition.face_encodings(elon_image)[0]